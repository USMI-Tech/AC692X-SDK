#ifndef __TASK_FM_KEY_H__
#define __TASK_FM_KEY_H__

#include "key.h"

extern const KEY_REG task_fm_key;

#endif
