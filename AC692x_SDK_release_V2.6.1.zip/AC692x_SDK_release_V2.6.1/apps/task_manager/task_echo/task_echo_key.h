#ifndef __TASK_ECHO_KEY_H__
#define __TASK_ECHO_KEY_H__

#include "key.h"

extern const KEY_REG task_echo_key;

#endif
