#ifndef __TASK_MUSIC_KEY_H__
#define __TASK_MUSIC_KEY_H__
#include "key.h"

extern const KEY_REG task_music_key;

#endif// __TASK_MUSIC_KEY_H__
