#ifndef __TASK_BT_KEY_H__
#define __TASK_BT_KEY_H__
#include "key.h"

extern const KEY_REG task_bt_key;

#endif// __TASK_BT_KEY_H__
