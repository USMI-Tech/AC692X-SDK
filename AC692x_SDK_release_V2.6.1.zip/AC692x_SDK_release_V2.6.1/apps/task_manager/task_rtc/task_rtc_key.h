#ifndef __TASK_RTC_KEY_H__
#define __TASK_RTC_KEY_H__
#include "key.h"

extern const KEY_REG task_rtc_key;

#endif// __TASK_RTC_KEY_H__
