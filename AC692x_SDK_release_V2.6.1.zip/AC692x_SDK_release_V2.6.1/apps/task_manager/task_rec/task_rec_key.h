#ifndef __TASK_REC_KEY_H__
#define __TASK_REC_KEY_H__
#include "key.h"

extern const KEY_REG task_rec_key;

#endif
