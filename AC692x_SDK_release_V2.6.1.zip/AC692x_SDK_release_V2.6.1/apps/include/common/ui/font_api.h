#ifndef _FONT_API_
#define _FONT_API_

bool font_init_api(u8 language);

#endif
