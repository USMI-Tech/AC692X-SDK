#ifndef _UICON_API_
#define _UICON_API_

bool uicon_init_api(void);

#endif
