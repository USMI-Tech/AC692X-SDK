#ifndef __FILE_OP_H__
#define __FILE_OP_H__

// #include "file_op_err.h"
// #include "logic_dev_list.h"

// u32 file_operate_get_total_phydev();
// u32 file_operate_ctl(u32 cmd,void *parm,void *input,void *output);
#endif//__FILE_OP_H__
