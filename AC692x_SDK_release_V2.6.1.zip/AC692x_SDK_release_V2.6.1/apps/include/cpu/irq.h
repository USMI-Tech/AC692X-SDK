#ifndef __IRQ_H__
#define __IRQ_H__

#include "typedef.h"


void app_irq_init() ;

#endif //__CLOCK_H__
