#ifndef _ALINK_H_
#define _ALINK_H_

void audio_link_init(void);
void audio_link_exit(void);

#endif
