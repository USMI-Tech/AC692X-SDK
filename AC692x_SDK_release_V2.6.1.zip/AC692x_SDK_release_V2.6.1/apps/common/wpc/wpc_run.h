#ifndef _WPC_RUN_H_
#define _WPC_RUN_H_

#include "typedef.h"

extern void wpc_uninit(void);

#endif
