#ifndef RAND64_H
#define RAND64_H

#include "typedef.h"

void get_random_number(u8 *ptr, u8 len);
u8  get_u8_random_number();

#endif

