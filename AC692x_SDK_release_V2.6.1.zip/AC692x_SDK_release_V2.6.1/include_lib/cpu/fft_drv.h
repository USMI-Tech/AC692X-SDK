#ifndef _FFT_DRV_H_
#define _FFT_DRV_H_

void fft_run(int *in, int *out, int forward, int nshift);

#endif
