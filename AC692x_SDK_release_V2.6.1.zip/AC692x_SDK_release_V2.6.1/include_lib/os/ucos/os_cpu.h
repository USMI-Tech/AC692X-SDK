/***********************************Jieli tech************************************************
  File : os_cpu.h
  By   : Juntham
  date : 2014-07-03 09:06
********************************************************************************************/
#ifndef _OS_CPU_H
#define _OS_CPU_H
#include "cpu.h"

#define  CPU_SR_ALLOC()
#define  OS_CPU_EXT     extern
#define  os_ctx_sw      OSCtxSw

#endif                                           /*_OS_CPU_H                                            */
